global using Xunit;
global using FluentAssertions;
global using NSubstitute;